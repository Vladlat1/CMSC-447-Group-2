Made by Wendy and Matthew
===========================
This is a flask created application with a login page and a navigation bar.

The command to run this: flask run

We left off the tutorial at: https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-iii-web-forms
specifically, "improving form validation" section
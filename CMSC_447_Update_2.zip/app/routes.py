from flask import Flask, render_template, redirect, url_for, request, flash
from app import app
from app.forms import LoginForm, ResponderForm, ResponderEntry, OperatorForm
import sqlite3
from sqlite3 import Error

def create_connection(db_file):
    """ create a database connection to the SQLite database
        specified by the db_file
    :param db_file: database file
    :return: Connection object or None
    """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
 
    return conn
    
#The Database
database = "mission.db"
#Dictionary for the username
user_variables = {"username": ""}
id = 0

# Route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
@app.route('/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    global id
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
                    
        # create a database connection
        conn = create_connection(database)   
        
        if form.new_user.data:
            cur = conn.cursor()
            cur.execute('SELECT ResponderID FROM Personnel ORDER BY ResponderID DESC LIMIT 1')
            id = int(cur.fetchone()[0]) + 1
            print(id)
            cur = conn.cursor()
            cur.execute('INSERT INTO Personnel(Username, Password, ResponderID, MissionID, Type) VALUES (?,?,?,?,?)', [username, password, id, 0,'responder']) 
            conn.commit()
        
        elif form.submit.data:
            cur = conn.cursor()
            cur.execute('SELECT * FROM Personnel WHERE UserName=? AND Password=?', [username, password])
            fetch = cur.fetchone()
            if not fetch is None: 
                user_variables["username"] = fetch[0]
                type = fetch[4]
                print(type)
                id = fetch[2]
                print(id)
                if (conn):
                    conn.close()
                    print("The SQLite connection is closed")
                    
                if type == "responder":
                    return redirect('/responder')
                elif type == "operator":
                    return redirect('/events')
            flash('Login requested for user {} failed...'.format(form.username.data))
            
        if (conn):
            conn.close()
            print("The SQLite connection is closed")
            
    return render_template('login.html', title='Sign In', form=form)
    
@app.route('/responder_profile', methods=['GET', 'POST'])
def responder_profile():
    """
    Called when the /responder_profile extension is used...
    When the save button is pressed the skills are collected.
    Then the database has the skill altered.
    """
    form = ResponderForm()
    if form.validate_on_submit():
        animal = form.animal.data
        fire = form.fire.data
        flood = form.flood.data
        medical = form.medical.data
        electrical = form.electrical.data
        other = form.other.data
        conn = create_connection(database)   
        cur = conn.cursor()
        print("ID: " + str(id))
        cur.execute('UPDATE SKILLS SET (Animal, Fire, Flood, Medical, Electrical, Other) = (?,?,?,?,?,?) WHERE ResponderID = ?',\
        [animal, fire, flood, medical, electrical, other, id])
        conn.commit()
        if (conn):
            conn.close()
            print("The SQLite connection is closed")
        return redirect('/responder')

    return render_template('responder_profile.html', title='Profile', form=form, user_variables=user_variables)
    
@app.route('/responder', methods=['GET', 'POST'])
def responder():
    form = ResponderEntry()
    print(request.method)
    conn = create_connection(database)   
    cur = conn.cursor()
    query = "SELECT Description.CaseID, Description.Name, Description.Desc FROM Personnel\
    INNER JOIN Cases ON Personnel.MissionID = Cases.MissionID\
    INNER JOIN Description on Description.CaseID = Cases.CaseID WHERE Personnel.ResponderID = ?"
    cur.execute(query, [id])
    fetch = cur.fetchall()
    description = fetch
        
    tags = [0,0,0,0,0,"",0]
    
    if request.method == "POST":
        print("Posted")
        for desc in description:
            print(desc[1] + " " + request.form['entry'])
            if request.form['entry'] == desc[1]:
                print("Request Form Success for " + str(desc[1]))
                query = "SELECT * FROM Tags WHERE Tags.CaseID = ?"
                cur.execute(query, [desc[0]])
                fetch = cur.fetchone()
                tags = fetch
                print(tags)
    #query = "SELECT * FROM Tags WHERE Tags.CaseID IN ({seq})".format(seq=','.join(['?']*len(description)))
    #cur.execute(query, [x[0] for x in description])
    if (conn):
        conn.close()
        print("The SQLite connection is closed")
    return render_template('responder.html', title='Responder', form=form, description=description, tags=tags)
    
@app.route('/events', methods=['GET', 'POST'])
def events():
    
    query = "SELECT LocX, LocY, Animal, Fire, Flood, Medical, Electrical, Other FROM Cases INNER JOIN Tags ON Cases.CaseID = Tags.CaseID";
    conn = create_connection(database)   
    cur = conn.cursor()
    cur.execute(query)
    locations = cur.fetchall()
    print(locations)
    locs = []
    i = 0
    for x, y, a, fire, flood, m, e, o in locations:
        locs.insert(i, x)
        locs.insert(i+1, y)
        locs.insert(i+2, a)
        locs.insert(i+3, fire)
        locs.insert(i+4, flood)
        locs.insert(i+5, m)
        locs.insert(i+6, e)
        i+=7
        
    i = 0
    others = []
    for loc in locations:
        others.insert(i, loc[7])
        i+=1
        
    form = OperatorForm()
    if form.validate_on_submit():
        location = form.location.data
        animal = form.animal.data
        fire = form.fire.data
        flood = form.flood.data
        medical = form.medical.data
        electrical = form.electrical.data
        other = form.other.data
       
    return render_template('operator.html', title='Events', form=form, locations=locs, others=others)


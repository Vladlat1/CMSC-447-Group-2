# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 16:29:11 2019

@author: daugh
"""

from app import app